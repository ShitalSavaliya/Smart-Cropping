<?php
// Check existence of id parameter before processing further
if(isset($_GET["id"]) && !empty(trim($_GET["id"]))){
    // Include config file
    //require_once 'config.php';
    $db_name="php_db";
	$db_user="root";
	$db_pass="";
	$host_name="localhost";
	$con=mysqli_connect($host_name,$db_user,$db_pass,$db_name);	
	if (!$con)
	{
		die('Could not connect: ' . mysql_error());
	}

    // Prepare a select statement
    $sql = "SELECT * FROM user WHERE userId = ?";
    
    if($stmt = mysqli_prepare($con, $sql)){
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt, "i", $param_id);
        
        // Set parameters
        $param_id = trim($_GET["id"]);
        
        // Attempt to execute the prepared statement
        if(mysqli_stmt_execute($stmt)){
            $result = mysqli_stmt_get_result($stmt);
    
            if(mysqli_num_rows($result) == 1){
                /* Fetch result row as an associative array. Since the result set
                contains only one row, we don't need to use while loop */
                $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
                
                // Retrieve individual field value
                
                $fname = $row["fname"];
                $lname = $row["lname"];
            } else{
                // URL doesn't contain valid id parameter. Redirect to error page
                header("location: error.php");
                exit();
            }
            
        } else{
            echo "Oops! Something went wrong. Please try again later.";
        }
    }
     
    // Close statement
    mysqli_stmt_close($stmt);
	 mysqli_close($con);
} else{
    // URL doesn't contain id parameter. Redirect to error page
    header("location: error.php");
    exit();
}
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>View Record</title>
	<!-- Bootstrap Styles-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FontAwesome Styles-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
        <!-- Custom Styles-->
    <link href="assets/css/custom-styles.css" rel="stylesheet" />
     <!-- Google Fonts-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
    <div id="wrapper">
        
        <!--/. NAV TOP  -->
        <?php 
			include "include/menu.php";
		?>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
			 <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-header">
                            Read User
                        </h1>
                    </div>
                </div> 
                 <!-- /. ROW  -->
              <div class="row">
                <div class="col-md-6 col-md-offset-2">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-md-10">
                                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                                       
                                      <div class="form-group">
                        <label>UserId:</label>
                        <?php  echo $row["userId"]; ?>
                    </div>
                    <div class="form-group">
                        <label>fname:</label>
                        <?php echo ""; echo $row["fname"]; ?>
                    </div>
                    <div class="form-group">
                        <label>lname:</label>
                        <?php echo ""; echo $row["lname"]; ?>
                    </div>
                    <div class="form-group">
                        <label>Username:</label>
                        <?php echo ""; echo $row["username"]; ?>
                    </div>
                    <div class="form-group">
                        <label>Password:</label>
                        <?php echo ""; echo $row["password"]; ?>
                    </div>
                    <div class="form-group">
                        <label>addR:</label>
                        <?php echo ""; echo $row["addR"]; ?>
                    </div>
                    <div class="form-group">
                        <label>addA:</label>
                        <?php echo ""; echo $row["addA"]; ?>
                    </div>
                    <div class="form-group">
                        <label>state:</label>
                        <?php echo ""; echo $row["state"]; ?>
                    </div>
                    <div class="form-group">
                        <label>city:</label>
                        <?php echo ""; echo $row["city"]; ?>
                    </div>
                    <div class="form-group">
                        <label>email:</label>
                        <?php echo ""; echo $row["email"]; ?>
                    </div>
                    <div class="form-group">
                        <label>contact:</label>
                        <?php echo ""; echo $row["contact"]; ?>
                    </div>
                    <p><a href="member.php" class="btn btn-primary">Back</a></p>
									</form>
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                                
                                <!-- /.col-lg-6 (nested) -->
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
			
			</div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- Bootstrap Js -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Metis Menu Js -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- Custom Js -->
    <script src="assets/js/custom-scripts.js"></script>
    
   
</body>
</html>
