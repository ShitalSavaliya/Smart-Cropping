<?php 
	$db_name="php_db";
											$db_user="root";
											$db_pass="";
											$host_name="localhost";

								$con=mysqli_connect($host_name,$db_user,$db_pass,$db_name);	
											if (!$con)
											{
												die('Could not connect: ' . mysql_error());
											}



?>


<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>UserDetails</title>
	<!-- Bootstrap Styles-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FontAwesome Styles-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
     <!-- Morris Chart Styles-->
   
        <!-- Custom Styles-->
    <link href="assets/css/custom-styles.css" rel="stylesheet" />
     <!-- Google Fonts-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
     <!-- TABLE STYLES-->
    <link href="assets/js/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
    
</head>
<body>
    <div id="wrapper">
        
        <!--/. NAV TOP  -->
        <?php
			include "include/menu.php";
		?>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
			 <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-header">
                            User Table  <small></small>
                        </h1>
                    </div>
                </div> 
                 <!-- /. ROW  -->
            <form name="from" action="">  
            <div class="row">
                <div class="col-md-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                             USER TABLE
                             <a href="add_user.php" class="btn btn-danger btn-sm" style="float: right;">Add User</a>
                             
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                           
                                            <th>#</th>
                                            <th>Fname</th>
                                            <th>Lname</th>
                                            <th>UserName</th>
                                            <th>Password</th>
                                            <th>Recidencial Address</th>
                                            <th>Area Address</th>
											<th>City</th>
                                       		<th>State</th>
                                       		<th>Occupation</th>
                                       		<th>Email_id</th>
                                       		<th>city</th>
                                       		<th>ACTION</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php

	   									$db_name="php_db";
										$db_user="root";
										$db_pass="";
										$host_name="localhost";

							$con=mysqli_connect($host_name,$db_user,$db_pass,$db_name);	
										if (!$con)
  										{
  											die('Could not connect: ' . mysql_error());
  										}
 

										$sql="SELECT * FROM user";
	   									$result = mysqli_query($con,$sql);
                                   		while($row = mysqli_fetch_array($result))
									  {
									  echo "<tr>";
										  echo "<td>" . $row['userId'] . "</td>";
									  echo "<td>" . $row['fname'] . "</td>";
									  echo "<td>" . $row['lname'] . "</td>";
									  echo "<td>" . $row['username'] . "</td>";
									  echo "<td>" . $row['password'] . "</td>";
										  echo "<td>" . $row['addR'] . "</td>";
										  echo "<td>" . $row['addA'] . "</td>";
										  echo "<td>" . $row['city'] . "</td>";
										  echo "<td>" . $row['state'] . "</td>";
										  echo "<td>" . $row['occupation'] . "</td>";
										  echo "<td>" . $row['email'] . "</td>";
										  echo "<td>" . $row['contact'] . "</td>";
										  echo "<td>";
                                            echo "<a href='readUser.php?id=". $row['userId'] ."' title='View Record' data-toggle='tooltip'><span class='glyphicon glyphicon-eye-open'></span></a>";
                                            echo "<a href='updateUser.php?userId=". $row['userId'] ."' title='Update Record' data-toggle='tooltip'><span class='glyphicon glyphicon-pencil'></span></a>";
                                            echo "<a href='deleteUser.php?userId=". $row['userId'] ."' title='Delete Record' data-toggle='tooltip'><span class='glyphicon glyphicon-trash'></span></a>";
                                        echo "</td>";
									  echo "</tr>";
									  }
									echo "</table>";

									mysqli_close($con);

									?>
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables2 -->
                </div>
            </div>
			</form>
        </div>
               
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
     <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- Bootstrap Js -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Metis Menu Js -->
    <script src="assets/js/jquery.metisMenu.js"></script>
     <!-- DATA TABLE SCRIPTS -->
    <script src="assets/js/dataTables/jquery.dataTables.js"></script>
    <script src="assets/js/dataTables/dataTables.bootstrap.js"></script>
        <script>
            $(document).ready(function () {
                $('#dataTables-example').dataTable();
            });
    </script>
         <!-- Custom Js -->
    <script src="assets/js/custom-scripts.js"></script>
    
   
</body>
</html>
