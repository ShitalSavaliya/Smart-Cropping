<?php
// Include config file
//require_once 'config.php';
 $db_name="php_db";
 $db_user="root";
	$db_pass="";
	$host_name="localhost";

	$con=mysqli_connect($host_name,$db_user,$db_pass,$db_name);	
	if (!$con)
  	{
  	die('Could not connect: ' . mysql_error());
	}
 
// Define variables and initialize with empty values
$fname = $lname = $username = $password = $addA = $addR = $contact = $email = $occupation = $state = $city = "";
$fname_err = $lname_err = $username_err = $password_err = $addA_err = $addR_err = $contact_err = $email_err = $occupation_err = $state_err = $city_err = "";
// Processing form data when form is submitted

    if(isset($_POST["userId"]) && !empty($_POST["userId"])){
    // Get hidden input value
    $userId = $_POST["userId"];
    
    
    $input_fname = trim($_POST["fname"]);
    if(empty($input_fname)){
        $fname_err = 'Please enter username.';     
    } else{
        $fname = $input_fname;
    }
    
    // Validate salary
    $input_lname = trim($_POST["lname"]);
    if(empty($input_lname)){
        $lname_err = "Please enter the password.";     
    } /*elseif(!ctype_digit($input_password)){
        $salary_err = 'Please enter a positive integer value.';
    } */else{
        $lname = $input_lname;
    }
		$input_username = trim($_POST["username"]);
	$username = $input_username;
	$input_password = trim($_POST["password"]);
	$password  = $input_password ;
	$input_addA = trim($_POST["addA"]);
	$addA  = $input_addA ;
	$input_addR = trim($_POST["addR"]);
	$addR  = $input_addR ;
	$input_email = trim($_POST["email"]);
	$email  = $input_email ;
	$input_contact = trim($_POST["contact"]);
	$contact  = $input_contact ;
	$input_occupation = trim($_POST["occupation"]);
	$occupation  = $input_occupation ;
	$input_state = trim($_POST["state"]);
	$state  = $input_state ;
	$input_city = trim($_POST["city"]);
	$city  = $input_city ;
    
    // Check input errors before inserting in database
    if(empty($fname_err) && empty($lname_err)){
        // Prepare an insert statement
        $sql = "UPDATE user SET  fname=?,lname=?,username=?, password=?,addR=?,addA=?,city=?,state=?,occupation=?,email=?,contact=?  WHERE userId=?";
         
        if($stmt = mysqli_prepare($con, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "ssssssssssss", $fname, $lname, $username, $password, $addR, $addA, $city, $state, $occupation, $email, $contact,  $userId);
            
            // Set parameters
            
            //$param_username = $username;
            //$param_password = $password;
            //$param_userId = $userId;
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Records updated successfully. Redirect to landing page
                header("location: member.php");
                exit();
            } else{
                echo "Something went wrong. Please try again later.";
            }
        }
         
        // Close statement
        mysqli_stmt_close($stmt);
	}
    
    // Close connection
    mysqli_close($con);
} else {
    // Check existence of id parameter before processing further
    if(isset($_GET["userId"]) && !empty(trim($_GET["userId"]))){
        // Get URL parameter
        $userId =  trim($_GET["userId"]);
        
        // Prepare a select statement
        $sql = "SELECT * FROM user WHERE userId = ?";
        if($stmt = mysqli_prepare($con, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "i", $param_userId);
            
            // Set parameters
            $param_userId = $userId;
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                $result = mysqli_stmt_get_result($stmt);
    
                if(mysqli_num_rows($result) == 1){
                    /* Fetch result row as an associative array. Since the result set
                    contains only one row, we don't need to use while loop */
                    $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
                    
                    // Retrieve individual field value
                    $fname=$row["fname"];
					$lname=$row["lname"];
                    $username = $row["username"];
                    $password = $row["password"];
					$occupation=$row["occupation"];
					$email=$row["email"];
					$contact=$row["contact"];
					$city=$row["city"];
					$state=$row["state"];
					$addA=$row["addA"];
					$addR=$row["addR"];
					
                } else{
                    // URL doesn't contain valid id. Redirect to error page
                    header("location: error.php");
                    exit();
                }
                
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }
        }
        
        // Close statement
        mysqli_stmt_close($stmt);
    }  else{
        // URL doesn't contain id parameter. Redirect to error page
        header("location: error.php");
        exit();
    }
}
?>
 
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Update User Details</title>
	<!-- Bootstrap Styles-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FontAwesome Styles-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
        <!-- Custom Styles-->
    <link href="assets/css/custom-styles.css" rel="stylesheet" />
     <!-- Google Fonts-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
    <div id="wrapper">
        
        <!--/. NAV TOP  -->
        <?php 
			include "include/menu.php";
		?>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
			 <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-header">
                            Update User 
                        </h1>
                    </div>
                </div> 
                 <!-- /. ROW  -->
              <div class="row">
                <div class="col-md-6 col-md-offset-2">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-md-10">
                                    <p>Please edit the input values and submit to update the record.</p>
                    <form action="<?php echo htmlspecialchars(basename($_SERVER['REQUEST_URI'])); ?>" method="post">
                        <div class="form-group <?php echo (!empty($fname_err)) ? 'has-error' : ''; ?>">
                            <label>Fname</label>
                            <input type="text" name="fname" class="form-control" value="<?php echo $fname; ?>">
                            <span class="help-block"><?php echo $fname_err;?></span>
						</div>
                       <div class="form-group <?php echo (!empty($lname_err)) ? 'has-error' : ''; ?>">
                            <label>Lname</label>
                            <input type="text" name="lname" class="form-control" value="<?php echo $lname; ?>">
                            <span class="help-block"><?php echo $lname_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($username_err)) ? 'has-error' : ''; ?>">
                            <label>Username</label>
                            <textarea name="username" class="form-control"><?php echo $username; ?></textarea>
                            <span class="help-block"><?php echo $username_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($password_err)) ? 'has-error' : ''; ?>">
                            <label>Password</label>
                            <input type="text" name="password" class="form-control" value="<?php echo $password; ?>">
                            <span class="help-block"><?php echo $password_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($addR_err)) ? 'has-error' : ''; ?>">
                            <label>addR</label>
                            <input type="text" name="addR" class="form-control" value="<?php echo $addR; ?>">
                            <span class="help-block"><?php echo $addR_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($addA_err)) ? 'has-error' : ''; ?>">
                            <label>addA</label>
                            <input type="text" name="addA" class="form-control" value="<?php echo $addA; ?>">
                            <span class="help-block"><?php echo $addA_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($state_err)) ? 'has-error' : ''; ?>">
                            <label>state</label>
                            <input type="text" name="state" class="form-control" value="<?php echo $state; ?>">
                            <span class="help-block"><?php echo $state_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($city_err)) ? 'has-error' : ''; ?>">
                            <label>city</label>
                            <input type="text" name="city" class="form-control" value="<?php echo $city; ?>">
                            <span class="help-block"><?php echo $city_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($occupation_err)) ? 'has-error' : ''; ?>">
                            <label>occupation</label>
                            <input type="text" name="occupation" class="form-control" value="<?php echo $occupation; ?>">
                            <span class="help-block"><?php echo $occupation_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($email_err)) ? 'has-error' : ''; ?>">
                            <label>email</label>
                            <input type="text" name="email" class="form-control" value="<?php echo $email; ?>">
                            <span class="help-block"><?php echo $email_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($contact_err)) ? 'has-error' : ''; ?>">
                            <label>contact</label>
                            <input type="text" name="contact" class="form-control" value="<?php echo $contact; ?>">
                            <span class="help-block"><?php echo $contact_err;?></span>
                        </div>
                        <input type="hidden" name="userId" value="<?php echo $userId;?>"/>
                        <input type="submit" class="btn btn-primary" value="Submit">
                        <a href="member.php" class="btn btn-default">Cancel</a>
                    </form>
                </div>
                                <!-- /.col-lg-6 (nested) -->
                                
                                <!-- /.col-lg-6 (nested) -->
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
			
			</div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- Bootstrap Js -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Metis Menu Js -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- Custom Js -->
    <script src="assets/js/custom-scripts.js"></script>
    
   
</body>
</html>
