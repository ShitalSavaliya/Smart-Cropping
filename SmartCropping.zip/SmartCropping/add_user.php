<?php
	$db_name="php_db";
	$db_user="root";
	$db_pass="";
	$host_name="localhost";
	$con=mysqli_connect($host_name,$db_user,$db_pass,$db_name);	
	if (!$con)
	{
		die('Could not connect: ' . mysql_error());
	}

$fname = $lname = $username = $password = $addA = $addR = $contact = $email = $occupation = $state = $city = "";
$fname_err = $lname_err = $username_err = $password_err = $addA_err = $addR_err = $contact_err = $email_err = $occupation_err = $state_err = $city_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
   
   $input_fname = trim($_POST["fname"]);
    if(empty($input_fname)){
        $id_err = 'Please enter fname.';     
    } else{
        $fname = $input_fname;
    }
    // Validate address
    $input_lname = trim($_POST["lname"]);
    if(empty($input_lname)){
        $lname_err = 'Please enter an cropname.';     
    } else{
        $lname = $input_lname;
    }
    $input_username = trim($_POST["username"]);
	$username = $input_username;
	$input_password = trim($_POST["password"]);
	$password  = $input_password ;
	$input_addA = trim($_POST["addA"]);
	$addA  = $input_addA ;
	$input_addR = trim($_POST["addR"]);
	$addR  = $input_addR ;
	$input_email = trim($_POST["email"]);
	$email  = $input_email ;
	$input_contact = trim($_POST["contact"]);
	$contact  = $input_contact ;
	$input_occupation = trim($_POST["occupation"]);
	$occupation  = $input_occupation ;
	$input_state = trim($_POST["state"]);
	$state  = $input_state ;
	$input_city = trim($_POST["city"]);
	$city  = $input_city ;
	
    
    // Check input errors before inserting in database
    if( empty($fname_err) && empty($lname_err)){
        // Prepare an insert statement
        $sql = "INSERT INTO user (userId,fname,lname,username,password,addR,addA,state,city,occupation,email,contact) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";
         
        if($stmt = mysqli_prepare($con, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt,'ssssssssssss',$userId,$fname,$lname,$username,$password,$addR,$addA,$state,$city,$occupation,$email,$contact);
            
            // Set parameters         
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Records created successfully. Redirect to landing page
                header("location: member.php");
                exit();
            } else{
                echo "Something went wrong. Please try again later.";
				header("location: error.php");
            }
        }
         
        // Close statement
        mysqli_stmt_close($stmt);
    }
    
    // Close connection
    mysqli_close($con);
}
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Add New User Detail</title>
	<!-- Bootstrap Styles-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FontAwesome Styles-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
        <!-- Custom Styles-->
    <link href="assets/css/custom-styles.css" rel="stylesheet" />
     <!-- Google Fonts-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
    <div id="wrapper">
        
        <!--/. NAV TOP  -->
        <?php 
			include "include/menu.php";
		?>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
			 <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-header">
                            Add User
                        </h1>
                    </div>
                </div> 
                 <!-- /. ROW  -->
              <div class="row">
                <div class="col-md-6 col-md-offset-2">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-md-10">
                                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                                       <?php
										//$fs='';
										//$a="SELECT * FROM crop WHERE id='".$_GET['id']."' ";
										//$r=mysqli_query($con,$a);
										//$fs=mysqli_fetch_row($r);
										
										?>
                                   <div class="form-group <?php echo (!empty($fname_err)) ? 'has-error' : ''; ?>">
                                            <label>fname</label>
                                            <input class="form-control" name="fname" value="<?php echo $fname; ?>">
                                            <span class="help-block"><?php echo $fname_err;?></span>
                                        </div>
                                    <div class="form-group <?php echo (!empty($lname_err)) ? 'has-error' : ''; ?>">
                                            <label>lname</label>
                                            <input class="form-control" name="lname" value="<?php echo $lname; ?>">
                                            <span class="help-block"><?php echo $lname_err;?></span>
                                        </div>
                                     <div class="form-group <?php echo (!empty($username_err)) ? 'has-error' : ''; ?>">
                                            <label>username</label>
                                            <input class="form-control" name="username" value="<?php echo $username; ?>">
                                            <span class="help-block"><?php echo $username_err;?></span>
                                        </div>
                                      <div class="form-group <?php echo (!empty($password_err)) ? 'has-error' : ''; ?>">
                                            <label>password</label>
                                            <input class="form-control" name="password" value="<?php echo $password; ?>">
                                            <span class="help-block"><?php echo $password_err;?></span>
                                        </div>
                                       <div class="form-group <?php echo (!empty($addR_err)) ? 'has-error' : ''; ?>">
                                            <label>addR</label>
                                            <input class="form-control" name="addR" value="<?php echo $addR; ?>">
                                            <span class="help-block"><?php echo $addR_err;?></span>
                                        </div>
                                        <div class="form-group <?php echo (!empty($addA_err)) ? 'has-error' : ''; ?>">
                                            <label>addA</label>
                                            <input class="form-control" name="addA"  value="<?php echo $addA; ?>">
                                            <span class="help-block"><?php echo $addA_err;?></span>
                                        </div>
                                        <div class="form-group <?php echo (!empty($city_err)) ? 'has-error' : ''; ?>">
                                            <label>City</label>
                                            <input class="form-control" name="city"  value="<?php echo $city;?>">
                                            <span class="help-block"><?php echo $city_err;?></span>
                                        </div>
                                        <div class="form-group <?php echo (!empty($quantity_state)) ? 'has-error' : ''; ?>">
                                            <label>state</label>
                                            <input class="form-control" name="state"  value="<?php echo $state; ?>" >
                                            <span class="help-block"><?php echo $state_err;?></span>
                                        </div>
                                        <!--<div class="form-group <?php //echo (!empty($quality_err)) ? 'has-error' : ''; ?>">
                                            <label>Selects</label>
                                            <select class="form-control" name="quality"  <?php //echo $quality; ?>>
                                                <option>high</option>
                                                <option>medium</option>
                                                <option>low</option>
                                            </select>
                                        </div>-->
                                        <div class="form-group <?php echo (!empty($occupation_err)) ? 'has-error' : ''; ?>">
                                            <label>occupation</label>
                                            <input class="form-control" name="occupation"  value="<?php echo $occupation; ?>">
                                            <span class="help-block"><?php echo $occupation_err;?></span>
                                        </div>
                                        <div class="form-group <?php echo (!empty($email_err)) ? 'has-error' : ''; ?>">
                                            <label>Email Id</label>
                                            <input class="form-control" name="email"  value="<?php echo $email; ?>">
                                            <span class="help-block"><?php echo $email_err;?></span>
                                        </div>
                                        <div class="form-group <?php echo (!empty($contact_err)) ? 'has-error' : ''; ?>">
                                            <label>Contact</label>
                                            <input class="form-control" name="contact"  value="<?php echo $contact; ?>">
                                            <span class="help-block"><?php echo $contact_err;?></span>
                                        </div>
                                       <input type="submit" class="btn btn-primary" value="Submit">
                        				<a href="member.php" class="btn btn-default">Cancel</a>
                                        <!--<button type="submit" class="btn btn-default">Submit Button</button>
                                        <button type="reset" class="btn btn-default">Reset Button</button>-->
                                        <!--<input type="hidden" id="id" name="id" value=" <?php //echo $_GET['EditId']?>">
                                        <input type="hidden" id="action" name="action" value="<?php //echo $_GET['action']; ?>">-->
                                    </form>
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                                
                                <!-- /.col-lg-6 (nested) -->
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
			
			</div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- Bootstrap Js -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Metis Menu Js -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- Custom Js -->
    <script src="assets/js/custom-scripts.js"></script>
    
   
</body>
</html>
