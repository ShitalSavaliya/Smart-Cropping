<?php
	$db_name="php_db";
	$db_user="root";
	$db_pass="";
	$host_name="localhost";
	$con=mysqli_connect($host_name,$db_user,$db_pass,$db_name);	
	if (!$con)
	{
		die('Could not connect: ' . mysql_error());
	}

$id = $cropname = $croptype = $quantity = $quality = $description = $duedate = "";
$id_err = $cropname_err = $croptype_err = $quantity_err = $quality_err
	= $description_err = $duedate_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
   
   $input_id = trim($_POST["id"]);
    if(empty($input_id)){
        $id_err = 'Please enter id.';     
    } else{
        $id = $input_id;
    }
    // Validate address
    $input_cropname = trim($_POST["cropname"]);
    if(empty($input_cropname)){
        $cropname_err = 'Please enter an cropname.';     
    } else{
        $cropname = $input_cropname;
    }
    $input_croptype = trim($_POST["croptype"]);
	$croptype = $input_croptype;
	$input_quality = trim($_POST["quality"]);
	$quality  = $input_quality ;
	$input_quantity = trim($_POST["quantity"]);
	$quantity  = $input_quantity ;
	$input_description = trim($_POST["description"]);
	$description  = $input_description ;
	$input_duedate = trim($_POST["duedate"]);
	$duedate  = $input_duedate ;
	
    
    // Check input errors before inserting in database
    if( empty($id_err) && empty($cropname_err)){
        // Prepare an insert statement
        $sql = "INSERT INTO crop (sr_no,id,cropname,croptype,quantity,quality,description,duedate) VALUES (?,?,?,?,?,?,?,?)";
         
        if($stmt = mysqli_prepare($con, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt,'ssssssss',$sr_no,$id, $cropname, $croptype,$quantity,$quality,$description,$duedate);
            
            // Set parameters         
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Records created successfully. Redirect to landing page
                header("location: crop.php");
                exit();
            } else{
                echo "Something went wrong. Please try again later.";
				header("location: error.php");
            }
        }
         
        // Close statement
        mysqli_stmt_close($stmt);
    }
    
    // Close connection
    mysqli_close($con);
}
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Add New Crop Details</title>
	<!-- Bootstrap Styles-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FontAwesome Styles-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
        <!-- Custom Styles-->
    <link href="assets/css/custom-styles.css" rel="stylesheet" />
     <!-- Google Fonts-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
    <div id="wrapper">
        
        <!--/. NAV TOP  -->
        <?php 
			include "include/menu.php";
		?>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
			 <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-header">
                            Add Crop 
                        </h1>
                    </div>
                </div> 
                 <!-- /. ROW  -->
              <div class="row">
                <div class="col-md-6 col-md-offset-2">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Basic Form Elements
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-md-10">
                                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                                       <?php
										//$fs='';
										//$a="SELECT * FROM crop WHERE id='".$_GET['id']."' ";
										//$r=mysqli_query($con,$a);
										//$fs=mysqli_fetch_row($r);
										
										?>
                                       <div class="form-group <?php echo (!empty($id_err)) ? 'has-error' : ''; ?>">
                                            <label>ID</label>
                                            <input class="form-control" name="id" value="<?php echo $id; ?>">
                                            <span class="help-block"><?php echo $id_err;?></span>
                                        </div>
                                        <div class="form-group <?php echo (!empty($cropname_err)) ? 'has-error' : ''; ?>">
                                            <label>Crop Name</label>
                                            <input class="form-control" name="cropname"  value="<?php echo $cropname; ?>">
                                            <span class="help-block"><?php echo $cropname_err;?></span>
                                        </div>
                                        <div class="form-group <?php echo (!empty($croptype_err)) ? 'has-error' : ''; ?>">
                                            <label>Crop Type</label>
                                            <input class="form-control" name="croptype"  value="<?php echo $croptype;?>">
                                            <span class="help-block"><?php echo $croptype_err;?></span>
                                        </div>
                                        <div class="form-group <?php echo (!empty($quantity_err)) ? 'has-error' : ''; ?>">
                                            <label>Quantity</label>
                                            <input class="form-control" name="quantity"  value="<?php echo $quantity; ?>" >
                                            <span class="help-block"><?php echo $quantity_err;?></span>
                                        </div>
                                        <!--<div class="form-group <?php //echo (!empty($quality_err)) ? 'has-error' : ''; ?>">
                                            <label>Selects</label>
                                            <select class="form-control" name="quality"  <?php //echo $quality; ?>>
                                                <option>high</option>
                                                <option>medium</option>
                                                <option>low</option>
                                            </select>
                                        </div>-->
                                        <div class="form-group <?php echo (!empty($quality_err)) ? 'has-error' : ''; ?>">
                                            <label>Quality</label>
                                            <input class="form-control" name="quality"  value="<?php echo $quality; ?>">
                                            <span class="help-block"><?php echo $quality_err;?></span>
                                        </div>
                                        <div class="form-group <?php echo (!empty($description_err)) ? 'has-error' : ''; ?>">
                                            <label>Description</label>
                                            <input class="form-control" name="description"  value="<?php echo $description; ?>">
                                            <span class="help-block"><?php echo $description_err;?></span>
                                        </div>
                                        <div class="form-group <?php echo (!empty($duedate_err)) ? 'has-error' : ''; ?>">
                                            <label>Due Date</label>
                                            <input class="form-control" name="duedate"  value="<?php echo $duedate; ?>">
                                            <span class="help-block"><?php echo $duedate_err;?></span>
                                        </div>
                                       <input type="submit" class="btn btn-primary" value="Submit">
                        				<a href="crop.php" class="btn btn-default">Cancel</a>
                                        <!--<button type="submit" class="btn btn-default">Submit Button</button>
                                        <button type="reset" class="btn btn-default">Reset Button</button>-->
                                        <!--<input type="hidden" id="id" name="id" value=" <?php //echo $_GET['EditId']?>">
                                        <input type="hidden" id="action" name="action" value="<?php //echo $_GET['action']; ?>">-->
                                    </form>
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                                
                                <!-- /.col-lg-6 (nested) -->
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
			
			</div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- Bootstrap Js -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Metis Menu Js -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- Custom Js -->
    <script src="assets/js/custom-scripts.js"></script>
    
   
</body>
</html>
