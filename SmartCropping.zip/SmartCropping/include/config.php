<?php
	session_start();
	mysql_connet("localhost","root"," ");
	mysql_select_db("php_db");
?>