<?php
// Include config file
//require_once 'config.php';
 $db_name="php_db";
 $db_user="root";
	$db_pass="";
	$host_name="localhost";

	$con=mysqli_connect($host_name,$db_user,$db_pass,$db_name);	
	if (!$con)
  	{
  	die('Could not connect: ' . mysql_error());
	}
 
// Define variables and initialize with empty values
$cropname = $croptype = $quantity = $quality = $description = $duedate = "";
$cropname_err = $croptype_err = $quantity_err = $quality_err
	= $description_err = $duedate_err = "";
 
// Processing form data when form is submitted

    if(isset($_POST["id"]) && !empty($_POST["id"])){
    // Get hidden input value
    $id = $_POST["id"];
    //$input_id = trim($_POST["id"]);
	//$id = $input_id;
    
    
    // Validate address
    $input_cropname = trim($_POST["cropname"]);
    if(empty($input_cropname)){
        $cropname_err = 'Please enter an cropname.';     
    } else{
        $cropname = $input_cropname;
    }
    $input_croptype = trim($_POST["croptype"]);
	$croptype = $input_croptype;
	$input_quality = trim($_POST["quality"]);
	$quality  = $input_quality ;
	$input_quantity = trim($_POST["quantity"]);
	$quantity  = $input_quantity ;
	$input_description = trim($_POST["description"]);
	$description  = $input_description ;
	$input_duedate = trim($_POST["duedate"]);
	$duedate  = $input_duedate ;
	
    
    // Check input errors before inserting in database
    if(empty($cropname_err)){
        // Prepare an insert statement
        $sql = "UPDATE crop SET  cropname=?, croptype=?,quantity=?, quality=?,description=?, duedate=? WHERE id=?";
         
        if($stmt = mysqli_prepare($con, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "sssssss", $cropname,$croptype,$quantity,$quality,$description,$duedate,$id);
            
            // Set parameters
            
            //$param_username = $username;
            //$param_password = $password;
            //$param_id = $id;
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Records updated successfully. Redirect to landing page
                header("location: crop.php");
                exit();
            } else{
                echo "Something went wrong. Please try again later.";
            }
        }
         
        // Close statement
        mysqli_stmt_close($stmt);
	}
    
    // Close connection
    mysqli_close($con);
} else {
    // Check existence of id parameter before processing further
    if(isset($_GET["id"]) && !empty(trim($_GET["id"]))){
        // Get URL parameter
        $id =  trim($_GET["id"]);
        
        // Prepare a select statement
        $sql = "SELECT * FROM crop WHERE id = ?";
        if($stmt = mysqli_prepare($con, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "i", $param_id);
            
            // Set parameters
            $param_id = $id;
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                $result = mysqli_stmt_get_result($stmt);
    
                if(mysqli_num_rows($result) == 1){
                    /* Fetch result row as an associative array. Since the result set
                    contains only one row, we don't need to use while loop */
                    $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
                    
                    // Retrieve individual field value
                    
                    $cropname = $row["cropname"];
                    $croptype = $row["croptype"];
					$quantity = $row["quantity"];
					$quality = $row["quality"];
					$description = $row["description"];
					$duedate = $row["duedate"];
					
                } else{
                    // URL doesn't contain valid id. Redirect to error page
                    header("location: error.php");
                    exit();
                }
                
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }
        }
        
        // Close statement
        mysqli_stmt_close($stmt);
    }  else{
        // URL doesn't contain id parameter. Redirect to error page
        header("location: error.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Update Crop Details</title>
	<!-- Bootstrap Styles-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FontAwesome Styles-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
        <!-- Custom Styles-->
    <link href="assets/css/custom-styles.css" rel="stylesheet" />
     <!-- Google Fonts-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
    <div id="wrapper">
        
        <!--/. NAV TOP  -->
        <?php 
			include "include/menu.php";
		?>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
			 <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-header">
                            Update Crop 
                        </h1>
                    </div>
                </div> 
                 <!-- /. ROW  -->
              <div class="row">
                <div class="col-md-6 col-md-offset-2">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-md-10">
                                    <p>Please edit the input values and submit to update the record.</p>
                    <form action="<?php echo htmlspecialchars(basename($_SERVER['REQUEST_URI'])); ?>" method="post">
                        
                        
                        <div class="form-group <?php echo (!empty($cropname_err)) ? 'has-error' : ''; ?>">
                            <label>Cropname</label>
                            <input type="text" name="cropname" class="form-control" value="<?php echo $cropname; ?>">
                            <span class="help-block"><?php echo $cropname_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($croptype_err)) ? 'has-error' : ''; ?>">
                            <label>Croptype</label>
                            <textarea name="croptype" class="form-control"><?php echo $croptype; ?></textarea>
                            <span class="help-block"><?php echo $croptype_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($quantity_err)) ? 'has-error' : ''; ?>">
                            <label>Quantity</label>
                            <textarea name="quantity" class="form-control"><?php echo $quantity; ?></textarea>
                            <span class="help-block"><?php echo $quantity_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($quality_err)) ? 'has-error' : ''; ?>">
                            <label>Quality</label>
                            <textarea name="quality" class="form-control"><?php echo $quality; ?></textarea>
                            <span class="help-block"><?php echo $quality_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($description_err)) ? 'has-error' : ''; ?>">
                            <label>Description</label>
                            <textarea name="description" class="form-control"><?php echo $description; ?></textarea>
                            <span class="help-block"><?php echo $description_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($duedate_err)) ? 'has-error' : ''; ?>">
                            <label>Duedate</label>
                            <textarea name="duedate" class="form-control"><?php echo $duedate; ?></textarea>
                            <span class="help-block"><?php echo $duedate_err;?></span>
                        </div>
                        <input type="hidden" name="id" value="<?php echo $id;?>"/>
                        <input type="submit" class="btn btn-primary" value="Submit">
                        <a href="crop.php" class="btn btn-default">Cancel</a>
                    </form>
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                                
                                <!-- /.col-lg-6 (nested) -->
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
			
			</div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- Bootstrap Js -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Metis Menu Js -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- Custom Js -->
    <script src="assets/js/custom-scripts.js"></script>
    
   
</body>
</html>
