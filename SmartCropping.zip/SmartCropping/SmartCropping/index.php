<!DOCTYPE html>
<?php
   if(count($_POST)>0) 
   {
	   $db_name="php_db";
$db_user="root";
$db_pass="";
$host_name="localhost";

$con=mysqli_connect($host_name,$db_user,$db_pass,$db_name);
      // username and password sent from form 
      
      $username = $_POST['username'];
      $password = $_POST['password']; 
      
      $sql = "SELECT id FROM admin WHERE username = '$username' and password ='$password'";
      $result = mysqli_query($con,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      //$active = $row['active'];
      
      $count = mysqli_num_rows($result);
      
      // If result matched $myusername and $mypassword, table row must be 1 row
		
      if($count == 1) {
         //session_register("myusername");
         //$_SESSION['login_user'] = $myusername;
         $message = "New User Added Successfully";
         echo("success");
        header("location: dashboard.php");
      }else {
         $message = "Your Login Name or Password is invalid";
		  echo("");
         echo("invalid");
      }
   }
?>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Welcom to Smart Cropping</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta name="description" content="" />
<meta name="author" content="http://webthemez.com" />
<!-- css -->
<link href="css/bootstrap.min.css" rel="stylesheet" />
<link href="css/fancybox/jquery.fancybox.css" rel="stylesheet"> 
<link href="css/flexslider.css" rel="stylesheet" /> 
<link href="et-line-font/style.css" rel="stylesheet" />
<link href="css/style.css" rel="stylesheet" />
 
<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->

</head>
<body>
<div id="wrapper" class="home-page">
	<!-- start header -->
	<header>
        <div class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php"><img src="img/logo.png" alt="logo"/></a>
                </div>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <div class="navbar-collapse collapse ">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="index.php">Home</a></li> 
						<li><a href="about.php">About Us</font></b></a></li>
						<li><a href="services.php">Services</a></li>
                        <!--<li><a href="portfolio.html">Portfolio</a></li>-->
                        <!--<li><a href="pricing.html">Pricing</a></li>-->
                        <li><a href="contact.php">Contact</a></li>
                    </ul>
					
                </div>
            </div>
        </div>
	</header>
	<!-- end header -->
	<!--------------------------------------------------------------->
	<head>
  <meta charset="UTF-8">
  <title>Simple Login Widget</title>
  
  
  <link rel='stylesheet prefetch' href='https://www.google.com/fonts#UsePlace:use/Collection:Roboto:400,300,100,500'>
<link rel='stylesheet prefetch' href='http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css'>
<link rel='stylesheet prefetch' href='https://www.google.com/fonts#UsePlace:use/Collection:Roboto+Slab:400,700,300,100'>

      <link rel="stylesheet" href="css/style1.css">

  
</head>

<body>
  <div id="successful_login" class="fix-middle">
  <div class="container text-center">
    <h1>Welcome back to the internet!</h1>
    <p>You've successfully managed to log into a nonexistant account in order to test a login dialog box.<br> If you like it, you are welcomed to use it wherever you want, no strings attached.<br><br><a href="#" class="link dialog-reset">Rerun the whole thing.</a></p>
  </div>
</div>
<div id="successful_registration" class="fix-middle">
  <div class="container text-center">
    <h1>Welcome to the Crop Market!</h1>
    <p>You've successfully managed to register for a nonexistant account in order to test a registration dialog box.<br> If you like it, you are welcomed to use it wherever you want, no strings attached.<br><br><a href="#" class="link dialog-reset">Rerun the whole thing.</a></p>
  </div>
</div>

<div id="dialog" class="dialog dialog-effect-in">
  <div class="dialog-front">
    <div class="dialog-content">
      <form id="login_form" class="dialog-form" action="" method="POST">
        <fieldset>
			
          <legend>Log in</legend>
		  <div class="message"><span></span><?php if(isset($message)) { echo $message; } ?></span></div>
          <div class="form-group">
            <label for="user_username" class="control-label">Username:</label>
            <input type="text" id="user_username" class="form-control" name="username" autofocus/>
          </div>
          <div class="form-group">
            <label for="user_password" class="control-label">Password:</label>
            <input type="password" id="user_password" class="form-control" name="password"/>
          </div>
          <div class="text-center pad-top-20">
            <p>Have you forgotten your<br><a href="#" class="link"><strong>username</strong></a> or <a href="#" class="link"><strong>password</strong></a>?</p>
          </div>
          <div class="pad-top-20 pad-btm-20">
            <input type="submit" class="btn btn-default btn-block btn-lg" value="Continue">
          </div>
          <div class="text-center">
            <p>Do you wish to register<br> for <a href="#" class="link user-actions"><strong>a new account</strong></a>?</p>
          </div>
        </fieldset>
      </form>
    </div>
  </div>
  <div class="dialog-back">
    <div class="dialog-content">
      <form id="register_form" class="dialog-form" action="" method="POST">
        <fieldset>
		
          <legend>Register</legend>
          <div class="form-group">
             <input type="text" id="user_username" class="form-control" name="first_name" placeholder="First Name" autofocus>
          </div>
		  <div class="form-group">
             <input type="text" id="user_username" class="form-control" name="last_name" placeholder="Last Name" autofocus>
          </div>
		  <div class="form-group">
             <input type="text" id="user_username" class="form-control" name="user_name" placeholder="User Name" autofocus>
          </div>
          <div class="form-group">
            <input type="password" id="user_password" class="form-control" name="user_password" placeholder="Password" autofocus/>
          </div>
          <div class="form-group">
            <input type="Confirm password" id="user_cnf_password" class="form-control" name="user_cnf_password" placeholder="Confirm Password" autofocus//>
          </div>
		  <div class="form-group">
            <input type="res_add" id="user_password" class="form-control" name="res_add" placeholder="Residecial Address" autofocus/>
          </div>
		  <div class="form-group">
            <input type="f/i_add" id="user_password" class="form-control" name="f/i_add" placeholder="Farm/Industry Address" autofocus/>
          </div>
		  <div class="form-group">
            <input type="Town/City" id="user_password" class="form-control" name="Town/City" placeholder="Town/City" autofocus/>
          </div>
		  <div class="form-group" type="Occ" id="user_password" class="form-control">
		 state &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		 <select>
  
  <option value="gujarat">Gujarat</option>
  <option value="rajasthan">Rajasthan</option>
  <option value="kerela">Kerala</option>
  <option value="maharashtra">Maharashtra</option>
</select>
          </div>
		  <hr>
		  
		  <div class="form-group" type="Occ" id="user_password" class="form-control">
		 Occupation &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		 <select>
  
  <option value="gujarat">Farmer</option>
  <option value="gujarat">Industrialist</option>
		  <div class="form-group">
            <input type="Email" id="user_password" class="form-control" name="Email" placeholder="Email" autofocus/>
          </div>
		  <div class="form-group">
            <input type="Contact" id="user_password" class="form-control" name="Contact" placeholder="Contact Number" autofocus/>
          </div>
		  <div class="text-center">
            <a href="otp_page.html" class="link user-actions"><strong>Submit and Verify...</strong></a>
          </div>
          <div class="form-group pad-top-20 form-group-checkbox">
            <div class="checkbox">
              <label>
                <input type="checkbox" id="user_terms" name="user_terms">
                I have read and I agree with the Terms and Conditions
              </label>
            </div>
          </div>
          <div class="pad-btm-20">
            <input type="submit" class="btn btn-default btn-block btn-lg" value="Continue"/>
          </div>
          <div class="text-center">
            <p>Return to <a href="#" class="link user-actions"><strong>log in page</strong></a>?</p>
          </div>
		  </div>
        </fieldset>
      </form>
    </div>
  </div>
</div>
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

    <script src="js/index1.js"></script>

</body>

	
	<!------------------>
	<section id="banner">
	 
	<!-- Slider -->
        <div id="main-slider" class="flexslider">
            <ul class="slides">
              <li>
                <img src="img/slides/m.jpg" alt="" />
                <div class="flex-caption">
                    
					 
					 
                </div>
              </li>
              <li>
                <img src="img/slides/m1.jpg" alt="" />
                <div class="flex-caption">
                     
					 
                </div>
				<li>
                <img src="img/slides/m4.jpg" alt="" />
                <div class="flex-caption">
                    
					 
                </div>
				<img src="img/slides/m3.jpg" alt="" />
                <div class="flex-caption">
                   
					 
                </div>
              </li>
            </ul>
        </div>
	<!-- -----------------------------------------------------end slider -------------------------------------------------->
 
	</section>
	<section class="hero-text">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<div class="aligncenter"><h1 class="aligncenter">Welcome to Smart Cropping.</h1>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores quae porro consequatur aliquam, incidunt eius magni provident, doloribus omnis minus temporibus perferendis nesciunt quam repellendus nulla nemo ipsum odit corrupti consequuntur possimus, vero mollitia velit ad consectetur. Alias, laborum excepturi nihil autem nemo numquam, ipsa architecto non, magni consequuntur quam.</div>
				
			</div>
		</div>
	</div>
	</section>
	
	
	<section id="content">
	
	
	<div class="container">
	    	<div class="row">
			<div class="col-md-12">
				<div class="aligncenter"><h2 class="aligncenter">Our Services</h2></div>
				<br/>
			</div>
		</div>
			<div class="row">
		<div class="skill-home"> <div class="skill-home-solid clearfix"> 
		<div class="col-md-3 text-center">
		<span class="icons c1"><i class="icon-upload"></i></span> <div class="box-area">
		<h3>BUY</h3> <p>Where you can "BUY" all the farm products. You can see farmer's profile and according to your choice in a profile you can directly contact to them.</p></div>
		</div>
		<div class="col-md-3 text-center"> 
		<span class="icons c2"><i class="icon-tools"></i></span> <div class="box-area">
		<h3>SELL</h3> <p>Where you can sell your farm products online. Your selling entries will be shown to all the site users, and if any interest found by buyer, he/she will directly contact you.</p></div>
		</div>
		<div class="col-md-3 text-center"> 
		<span class="icons c3"><i class="icon-gift"></i></span> <div class="box-area">
		<h3>WEATHER</h3> <p>Climate change and agriculture are interrelated processes, both of which take place on a global scale. Climate change affects agriculture in a number of ways, including through changes in average temperatures, rainfall, and climate extremes</p></div>
		</div>
		<div class="col-md-3 text-center"> 
		<span class="icons c4"><i class="icon-trophy"></i></span> <div class="box-area">
		<h3>MARKET</h3> <p>The present APMC system makes farmers vulnerable to traders' and marketing agents' price manipulations. The Government of India is considering improving the APMC Act to benefit all parties involved.</p>
		</div></div>
		</div></div>
		</div> 
	 

	</div>
	</section>
	<!--<div class="features-content">

                <div class="row features-content-row">
                    <div class="col-sm-6 home-img  img">
                        <div class="home-img-inner ">
                            <div>&nbsp;</div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-sm-offset-6 home-img">
                        <div class="home-img-inner our-features">
                           <h3 class="wow animated fadeInDownfadeInRight animated">Our Awesome Features</h3>
                        <div class="features-box wow animated fadeInRight animated" style="visibility: visible; animation-name: fadeInRight;">
                            <div class="features-box-icon">
                                <i class="icon-search"></i>
                            </div><!--services icon-->
                          <!--  <div class="features-box-info">
                                <h4>Top Web Business Service</h4>
                                <p>
                                    Lorem ipsum dolor sitamet, consec tetur adipisicing elit. Dolores quae porro consequatur aliquam, incidunt eius magni provident
                                </p>
                            </div>
                        </div><!--service box-->
                        <!--<div class="features-box wow animated fadeInRight animated" style="visibility: visible; animation-name: fadeInRight;">
                            <div class="features-box-icon">
                                <i class="icon-envelope"></i>
                            </div><!--services icon-->
                           <!-- <div class="features-box-info">
                               <!-- <h4>Cloude Servers Provider</h4>
                                <p>
                                   Lorem ipsum dolor sitamet, consec tetur adipisicing elit. Dolores quae porro consequatur aliquam, incidunt eius magni provident
                                </p>
                            </div>
                        </div><!--service box-->

                       <!-- <div class="features-box wow animated fadeInRight animated" style="visibility: visible; animation-name: fadeInRight;">
                            <div class="features-box-icon">
                                <i class="icon-bargraph"></i>
                            </div><!--services icon-->
                           <!-- <div class="features-box-info">
                                <h4>Web Design and Development</h4>
                                <p>
                                    Lorem ipsum dolor sitamet, consec tetur adipisicing elit. Dolores quae porro consequatur aliquam, incidunt eius magni provident
                                </p>
                            </div>-->
                           
                        <!--</div><!--service box-->
						
						<!-- <div class="features-box wow animated fadeInRight animated" style="visibility: visible; animation-name: fadeInRight;">
                            <div class="features-box-icon">
                                <i class="icon-strategy"></i>
                            </div><!--services icon-->
                           <!-- <div class="features-box-info">
                                <h4>Amazing Features</h4>
                                <p>
                                    Lorem ipsum dolor sitamet, consec tetur adipisicing elit. Dolores quae porro consequatur aliquam, incidunt eius magni provident
                                </p>
                            </div>
                           
                        </div><!--service box-->

                        </div>
                    </div>
                </div>
            </div>
		 
	<!--<section id="clients">
        <div class="container">
            	<div class="row">
			<div class="col-md-12">
				<div class="aligncenter"><h2 class="aligncenter">Clients</h2></div>
				<br/>
			</div>
		</div>
            <div class="row">
                <div class="col-md-2 col-sm-4 client">
                    <div class="img client1"></div>
                </div>
                <div class="col-md-2 col-sm-4 client">
                    <div class="img client2"></div>
                </div>
                <div class="col-md-2 col-sm-4 client">
                    <div class="img client3"></div>
                </div>
                <div class="col-md-2 col-sm-4 client">
                    <div class="img client1"></div>
                </div>
                <div class="col-md-2 col-sm-4 client">
                    <div class="img client2"></div>
                </div>
                <div class="col-md-2 col-sm-4 client">
                    <div class="img client3"></div>
                </div>
            </div>
        </div>
    </section>
	
	<section class="testimonial-area">
    <div class="testimonial-solid">
        <div class="container">
            <div class="testi-icon-area">
                <div class="quote">
                    <i class="icon-megaphone"></i>
                </div>
            </div>
            <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                <ol class="carousel-indicators">
                    <li data-target="#carousel-example-generic" data-slide-to="0" class="">
                        <a href="#"></a>
                    </li>
                    <li data-target="#carousel-example-generic" data-slide-to="1" class="">
                        <a href="#"></a>
                    </li>
                    <li data-target="#carousel-example-generic" data-slide-to="2" class="active">
                        <a href="#"></a>
                    </li>
                    <li data-target="#carousel-example-generic" data-slide-to="3" class="">
                        <a href="#"></a>
                    </li>
                </ol>
                <div class="carousel-inner">
                    <div class="item">
                        <p>Blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi.</p>
                        <p>
                            <b>- Mark John -</b>
                        </p>
                    </div>
                    <div class="item">
                        <p>Blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi.</p>
                        <p>
                            <b>- Jaison Warner -</b>
                        </p>
                    </div>
                    <div class="item active">
                        <p>Blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi.</p>
                        <p>
                            <b>- Tony Antonio -</b>
                        </p>
                    </div>
                    <div class="item">
                        <p>Blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi.</p>
                        <p>
                            <b>- Leena Doe -</b>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
	</section>-->
	<footer>
	<div class="container">
		<div class="row">
			<div class="col-lg-3">
				<div class="widget">
					<h5 class="widgetheading">Our Contact</h5>
					<address>
					<strong>Smart Cropping </strong><br>
					Vitthal Udhyognagar,GIDC area,
					New vvnagar,
					ANAND-380121</address>
					<p>
						<i class="icon-phone"></i> (123) 456-789 - 1255-12584 <br>
						<i class="icon-envelope-alt"></i> email@domainname.com
					</p>
				</div>
			</div>
			<div class="col-lg-3">
				<div class="widget">
					<h5 class="widgetheading">Quick Links</h5>
					<ul class="link-list">
						<li><a href="#">Latest Events</a></li>
						<li><a href="#">Terms and conditions</a></li>
						<li><a href="#">Privacy policy</a></li>
						<li><a href="#">Career</a></li>
						<li><a href="#">Contact us</a></li>
					</ul>
				</div>
			</div>
			<div class="col-lg-3">
				<div class="widget">
					<h5 class="widgetheading">Latest posts</h5>
					<ul class="link-list">
						<li><a href="#">Smart Crop.</a></li>
						<li><a href="#">Sellar's List.</a></li>
						<li><a href="#">Weather and Market</a></li>
					</ul>
				</div>
			</div>
			<div class="col-lg-3">
				<div class="widget">
					<h5 class="widgetheading">Recent News</h5>
					<ul class="link-list">
						<li><a href="#">Soon, Provident Fund withdrawal claims can be settled through your smartphones.</a></li>
						<li><a href="#">Rajasthan to host mega-agri summit on november 9.</a></li>
						<li><a href="#"></a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
	<div id="sub-footer">
		<div class="container">
			<div class="row">
				<div class="col-lg-6">
					<div class="copyright">
						<p>
							<span>&copy; Smart Cropping 2018 All right reserved. By </span><a href="http://webthemez.com" Assure="_blank">WebThemez</a>
						</p>
					</div>
				</div>
				<div class="col-lg-6">
					<ul class="social-network">
						<li><a href="#" data-placement="top" title="Facebook"><i class="fa fa-facebook"></i></a></li>
						<li><a href="#" data-placement="top" title="Twitter"><i class="fa fa-twitter"></i></a></li>
						<li><a href="#" data-placement="top" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
						<li><a href="#" data-placement="top" title="Pinterest"><i class="fa fa-pinterest"></i></a></li>
						<li><a href="#" data-placement="top" title="Google plus"><i class="fa fa-google-plus"></i></a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
	</footer>
</div>
<a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>
<!-- javascript
    ================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="js/jquery.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.fancybox.pack.js"></script>
<script src="js/jquery.fancybox-media.js"></script> 
<script src="js/portfolio/jquery.quicksand.js"></script>
<script src="js/portfolio/setting.js"></script>
<script src="js/jquery.flexslider.js"></script>
<script src="js/animate.js"></script>
<script src="js/custom.js"></script>
</body>
</html>